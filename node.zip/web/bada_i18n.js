/**
 * ComfyUI-Bada-Utils Comprehensive 2-Tier i18n Translation Engine
 * - Tier 1: ComfyUI Native Settings UI Language (Automatically synced with ComfyUI's Locale)
 * - Tier 2: Bada Master Language Switch (Controls canvas nodes, badges, context menus, modals, sidebars)
 */

import { app as comfyApp } from "../../scripts/app.js";

export const BadaI18n = {
    _lang: null,
    get lang() {
        if (!this._lang) {
            this._lang = this.getBadaLanguage();
        }
        return this._lang;
    },
    set lang(val) {
        this._lang = val;
    },
    listeners: new Set(),

    dict: {
        en: {
            // --- Settings Tab ---
            "category": "⚓ Bada Utils",
            "settings_lang": "UI Language",
            "settings_lang_desc": "Controls language for all Bada nodes, context menus, modals, and Workflows+",
            "blank_canvas": "Clean Blank Canvas on Startup",
            "blank_canvas_desc": "Starts ComfyUI with an empty clean canvas instead of the default missing-model workflow.",
            "mouse_fix": "Smooth Mouse Pan & Wheel Zoom Fixer",
            "mouse_fix_desc": "Allows middle-click panning and wheel zooming seamlessly even over nodes and text widgets.",
            "auto_assign": "Auto Model & LoRA Assigner Alert",
            "auto_assign_desc": "Automatically detects missing models/LoRAs when loading workflows and prompts smart local matching.",
            "sidebar_organizer": "Sidebar Workflow Folder Management",
            "sidebar_organizer_desc": "Enables drag-and-drop workflow folder moving and organization in the left sidebar.",
            "load_image_fix": "Clipboard & LoadImage Auto-Error Fixer",
            "load_image_fix_desc": "Automatically fixes red border and input validation errors caused by pasting clipboard images (Ctrl+V) or subfolder paths in LoadImage nodes.",

            // --- Bada Preset Hub (Canvas Node) ---
            "hub_node_title": "⚓ Bada Preset Hub",
            "hub_select_nodes": "💡 Select node(s) on canvas (Ctrl+Click / Drag)",
            "hub_detected_nodes": "🎯 Detected: {count} Nodes (Ready to Save)",
            "hub_settings_btn": "⚙️ Settings",
            "hub_presets_header": "📜 Bada Presets ({count})",
            "hub_click_apply": "⚡ Click to Apply Instantly",
            "hub_empty_hint": "💡 Select node(s) and click top button to save a preset",
            "hub_switch_on": "ON",
            "hub_switch_off": "OFF",

            // --- Smart Presets Context Menu & Roof Badges ---
            "ctx_global_presets": "⚓ Global Presets ({count})",
            "ctx_save_current": "💾 Save Current Settings as Global Preset...",
            "ctx_auto_assign_all": "⚓ [Bada] Node Smart Care",
            "ctx_auto_assign_node": "⚡ [Bada] Auto-Assign Node Models",
            "badge_global_title": "🌐 Global Presets ({count})",
            "badge_global_desc": "Stored in ComfyUI globally across all workflows for <b>{name}</b>.",
            "badge_global_action": "👉 Click to open Global Presets Manager",
            "badge_hub_title": "⚓ Bada Preset Hub Link ({count})",
            "badge_hub_desc": "<b>{name}</b> is linked to {count} preset(s) in the Hub.",
            "badge_hub_action": "👉 Click to open Bada Preset Hub Manager",

            // --- Global Presets Modal ---
            "modal_global_title": "🌐 {name} Global Presets Manager",
            "modal_global_subtitle": "Node Type: {type} · Stored globally in ComfyUI (Instantly shared across all workflows)",
            "modal_global_input_placeholder": "Enter new global preset name (e.g. Fast Turbo 8step)...",
            "modal_global_save_btn": "💾 Save Current Settings",
            "modal_global_empty": "No saved presets.<br>Enter a name above and click <b>[Save Current Settings]</b>!",
            "modal_global_hint": "💡 Click tags (Pill) or switches to toggle options <b>ON/OFF</b>. Click <b>[Details]</b> to edit and save values.",
            "modal_apply_btn": "▶ Apply Instantly",
            "modal_details_btn": "Details",
            "modal_collapse_btn": "Collapse",
            "modal_export_btn": "📤 Backup (Export)",
            "modal_import_btn": "📥 Load (Import)",
            "modal_guide_btn": "💡 Backup & Cross-Workflow Guide",
            "modal_close_btn": "Close",

            // --- Bada Preset Hub Modal ---
            "modal_hub_title": "Bada Preset Hub Manager",
            "modal_hub_subtitle": "Bada presets are <strong>saved only within the current workflow</strong> and embedded in PNG metadata",
            "modal_hub_input_placeholder": "Enter universal preset name (e.g. FLUX Detailer Setup)...",
            "modal_hub_save_btn": "💾 Save from Current Selection",
            "modal_hub_empty": "No saved universal presets.<br>Select nodes on canvas and click <b>[Save from Current Selection]</b>!",
            "modal_hub_selected_count": "🎯 Selected Canvas Nodes ({count})",
            "modal_hub_no_selection": "⚠️ No nodes selected on canvas. Please select nodes first!",
            "modal_hub_empty_badge": "⚠️ No nodes selected (0)",
            "modal_hub_empty_desc": "Please select nodes to group on canvas (<b>Ctrl + Click</b> or <b>Shift + Drag</b>) before saving.",
            "modal_hub_target_badge": "🎯 Target Nodes: <strong>{count} selected</strong>",
            "modal_hub_target_hint": "※ All settings of the nodes below will be saved as a snapshot preset.",
            "modal_hub_bypass_state": "🟣 Bypass Active",
            "modal_hub_mute_state": "🔴 Mute Active",
            "modal_hub_lora_none": "LoRA: No active items",
            "modal_hub_text_prefix": "Text",
            "modal_hub_default_params": "Default parameters linked",
            "modal_hub_bypass_config": "Bypass configuration",
            "toast_hub_export_success": "📤 Universal preset backup JSON file downloaded.",
            "toast_hub_import_success": "📥 Universal presets successfully imported!",
            "toast_hub_import_error": "⚠️ Error reading JSON file: ",
            "toast_global_export_success": "📤 Global presets backup JSON file downloaded.",
            "toast_global_import_success": "📥 Global presets successfully imported!",

            // --- Workflows+ Sidebar ---
            "wf_tab_native": "Workflows",
            "wf_tab_plus": "⚓ Workflows+",
            "wf_search_placeholder": "Search workflows...",
            "wf_btn_focus": "Locate currently active workflow",
            "wf_btn_font_size": "Font Size (Click: Cycle / Right-click: Menu)",
            "wf_btn_new_folder": "New Folder",
            "wf_btn_toggle_all": "Expand / Collapse All",
            "wf_btn_refresh": "Refresh",
            "wf_root_dropzone": "🏠 Drop here to move to Root folder",
            "wf_empty_search": "No search results found.",
            "wf_empty_list": "No workflows found.<br>Click ➕ above to create a new folder.",
            "wf_active_tag": "● Active",
            "wf_bookmarks_header": "Bookmarks",
            "wf_browse_header": "Browse",
            "wf_ctx_load": "Load to Canvas",
            "wf_ctx_fav_add": "Add to Bookmarks",
            "wf_ctx_fav_remove": "Remove from Bookmarks",
            "wf_ctx_move": "Move to Folder...",
            "wf_ctx_new_subfolder": "New Subfolder",
            "wf_ctx_rename": "Rename",
            "wf_ctx_delete": "Delete",
            "wf_ctx_edit_info": "Edit Info & Thumbnail...",
            "wf_info_modal_title": "⚓ Workflow Info & Thumbnail",
            "wf_notes_label": "Notes & Description",
            "wf_notes_placeholder": "Enter workflow usage, tips, recommended models...",
            "wf_thumb_label": "Cover Thumbnail",
            "wf_thumb_canvas_btn": "⚡ Set Latest Canvas Output",
            "wf_thumb_paste_btn": "📋 Paste Clipboard (Ctrl+V)",
            "wf_thumb_upload_btn": "📁 Upload Image...",
            "wf_thumb_remove_btn": "🗑️ Remove",
            "wf_thumb_drop_hint": "Drop image here, or press Ctrl+V to paste",
            "wf_thumb_pasted_toast": "Image pasted from clipboard.",
            "wf_save_btn": "Save Info",
            "wf_info_saved_toast": "Workflow info & thumbnail saved successfully.",
            "wf_no_info_hint": "No notes or thumbnail recorded.<br>(Right-click to edit info)",
            "wf_card_path_label": "Path",
            "wf_card_notes_label": "Notes",
            "wf_modal_move_title": "📁 Move Workflow",
            "wf_modal_move_dest": "Select Destination Folder",
            "wf_modal_move_or_sub": "Or Create New Subfolder",
            "wf_modal_move_btn": "Move",
            "wf_modal_mkdir_title": "➕ Create New Folder",
            "wf_modal_mkdir_parent": "Parent Folder",
            "wf_modal_mkdir_name": "New Folder Name",
            "wf_modal_mkdir_btn": "Create",
            "wf_modal_rename_title": "✏️ Rename {type}",
            "wf_modal_rename_btn": "Rename",
            "wf_modal_delete_title": "🗑️ Delete {type}",
            "wf_modal_delete_confirm": "Are you sure you want to delete <strong>'{name}'</strong> {target}?",
            "wf_modal_delete_btn": "Delete",
            "wf_cancel_btn": "Cancel",

            // --- Save As Folder Picker ---
            "wf_saveas_title": "💾 Save Workflow As (Choose Folder)",
            "wf_saveas_folder": "📁 Destination Folder",
            "wf_saveas_root": "Root (top level)",
            "wf_saveas_name": "📄 File Name",
            "wf_saveas_name_required": "Please enter a file name.",
            "wf_saveas_path": "Target path",
            "wf_saveas_exists": "(a file with this name already exists - you will be asked to overwrite)",
            "wf_saveas_confirm": "Save",
            "wf_saveas_new_folder": "➕ New Folder",
            "wf_saveas_new_folder_ph": "New folder name",
            "wf_saveas_new_folder_btn": "Create",
            "wf_saveas_new_folder_done": "Folder '{folder}' created.",
            "wf_saveas_selected": "Selected folder",
            "wf_saveas_tree_hint": "Click = select · ▶/▼ or double-click = expand · Arrow keys to navigate",


            // --- Settings Tab ---
            "category": "⚓ Bada Utils",
            "settings_cat_general": "1. General",
            "settings_cat_smart": "2. Smart Features",
            "settings_cat_workflow": "3. Workflow & QoL",
            "settings_cat_startup": "4. Startup Behavior",
            "settings_cat_presets": "5. Global Presets",
            "settings_cat_image": "6. Image & Clipboard QoL",
            "settings_name_lang": "🌐 UI Language",
            "settings_name_sidebar": "📁 Sidebar Workflow Folder Management",
            "settings_name_mouse": "🖱️ Smooth Mouse Pan & Wheel Zoom Fixer",
            "settings_name_blank": "🧼 Clean Blank Canvas Startup",
            "settings_name_presets": "Global Presets",
            "settings_name_loadimage": "📋 Clipboard & LoadImage Auto-Error Fixer",
            "settings_desc_lang": "Set display language for Bada nodes, context menus, modals, and Workflows+ sidebar.",
            "settings_desc_sidebar": "Organize and move workflow folders via drag-and-drop in the left sidebar.",
            "settings_desc_mouse": "Smooth mouse wheel zooming and middle-click panning even over canvas nodes or text widgets.",
            "settings_desc_blank": "Start ComfyUI and new tabs with a clean blank canvas instead of default workflows with missing-model errors.",
            "settings_desc_loadimage": "Automatically fixes red border and input validation errors caused by pasting clipboard images (Ctrl+V) or subfolder paths in LoadImage nodes.",

            // --- Auto Model & LoRA Assigner ---
            "aa_modal_title": "⚡ Smart Model & LoRA Assigner & Folder Browser",
            "aa_summary_missing": "Review and assign missing models with local PC folder explorer, or switch to your desired model.",
            "aa_badge_missing": "⚠️ {missingCount} Missing / Total {totalCount} Nodes",
            "aa_summary_ok": "All models are properly loaded. You can browse or replace models from the folder tree.",
            "aa_badge_ok": "✅ All {totalCount} Models Loaded",
            "aa_footer_notice": "※ Skipped nodes will retain their original model names.",
            "aa_btn_cancel": "Close",
            "aa_btn_apply": "⚡ Apply Selected Models",
            "aa_skip_current": "(Skip / Keep Current)",
            "aa_smart_match": "Smart Match:",
            "aa_folder_tree_open": "📂 Open Folder Tree",
            "aa_folder_tree_close": "📂 Close Folder Tree",
            "aa_manual_select": "Manual Selection",
            "aa_toast_applied": "✅ Successfully applied {count} model(s)!",
            "aa_toast_none": "No changes were made.",

            // --- Gemini Studio ---
            "gem_apikey_section": "🔑 API Key & Priority Model Selection",
            "gem_apikey_placeholder": "Enter Google Gemini API Key...",
            "gem_apikey_save": "Save Key",
            "gem_apikey_saved": "Key saved!",
            "gem_gen_btn": "✨ Generate AI Prompt (Shift+Enter)",
            "gem_gen_running": "Generating prompt...",
            "gem_copy_prompt": "📋 Copy Prompt",
            "gem_copy_notes": "📝 Copy Notes",
            "gem_tab_chat": "✨ Uncensored Gemini (Chat)",
            "gem_toggle_nsfw_title": "Allow NSFW Content",
            "gem_toggle_nsfw_desc": "Uncensored sensual & intimate scenes",
            "gem_toggle_trans_title": "Korean Translation & Notes",
            "gem_toggle_trans_desc": "Separate English prompt and director notes",
            "gem_prompt_input_placeholder": "Describe the scene, character, or idea in detail...",

            // --- Regional Prompt ---
            "rp_art_style": "Style:",
            "rp_hyper_real": "Hyper Real",
            "rp_semi_real": "Semi Real",
            "rp_anime": "2D",
            "rp_character": "Character",
            "rp_3d": "3D",
            "rp_none": "None",
            "rp_white_bg": "White BG",
            "rp_grid_lines": "Grid Lines",
            "rp_silhouette": "Silhouette",
            "rp_global_char": "Global Appearance",
            "rp_char_preset_btn": "Appearance Presets",
            "rp_select_area_hint": "📍 Select a region to edit",
            "rp_apply_btn": "Apply (Ctrl+Enter)",
            "rp_copy_btn": "Copy Prompt",
            "rp_reset_btn": "Reset",
            "rp_final_preview": "Final Prompt Preview",

            // --- Bada Google Translator ---
            "trans_node_title": "⚓ Bada Google Translator",
            "trans_label_text": "text",
            "trans_label_from": "from_lang",
            "trans_label_to": "to_lang",
            "trans_label_quotes": "preserve_quotes",
            "trans_tip_quotes": "When true, text inside double quotes (\" \") is preserved without translation."
        },

        ko: {
            // --- Settings Tab ---
            "category": "⚓ Bada Utils",
            "settings_cat_general": "1. 일반",
            "settings_cat_smart": "2. 스마트 기능",
            "settings_cat_workflow": "3. 워크플로우 & 편의성",
            "settings_cat_startup": "4. 시작 환경",
            "settings_cat_presets": "5. 글로벌 프리셋",
            "settings_cat_image": "6. 이미지 & 클립보드 편의성",
            "settings_name_lang": "🌐 UI 언어 설정",
            "settings_name_sidebar": "📁 사이드바 워크플로우 폴더 관리",
            "settings_name_mouse": "🖱️ 부드러운 마우스 휠 줌 & 패닝 보정기",
            "settings_name_blank": "🧼 시작 시 클린 빈 캔버스로 열기",
            "settings_name_presets": "글로벌 프리셋",
            "settings_name_loadimage": "📋 클립보드 & LoadImage 자동 에러 해결사",
            "settings_desc_lang": "Bada 모든 노드, 우클릭 메뉴, 모달 창, Workflows+의 표시 언어를 제어합니다.",
            "settings_desc_sidebar": "왼쪽 사이드바에서 드래그 앤 드롭으로 워크플로우 폴더를 자유롭게 정리하고 이동합니다.",
            "settings_desc_mouse": "노드 위나 텍스트 박스 위에서도 휠 줌 및 중간 버튼 패닝이 막힘없이 부드럽게 작동합니다.",
            "settings_desc_blank": "ComfyUI 실행 시 모델 누락 에러가 나는 기본 워크플로우 대신 깨끗한 빈 캔버스로 시작합니다.",
            "settings_desc_loadimage": "LoadImage 노드에 클립보드 이미지(Ctrl+V)를 붙여넣거나 하위 경로 로드 시 발생하는 빨간 테두리 에러를 자동으로 치료합니다.",

            // --- Auto Model & LoRA Assigner ---
            "aa_modal_title": "⚡ 모델 / LoRA 스마트 자동 장착 & 폴더 탐색기",
            "aa_summary_missing": "누락된 모델을 내 PC 폴더 탐색기로 확인 및 장착하거나, 원하는 모델로 즉시 변경할 수 있습니다.",
            "aa_badge_missing": "⚠️ {missingCount}개 누락됨 / 총 {totalCount}개 노드",
            "aa_summary_ok": "모든 모델이 정상 장착되어 있습니다. 폴더 트리에서 모델을 확인하거나 다른 모델로 교체할 수 있습니다.",
            "aa_badge_ok": "✅ 전체 {totalCount}개 정상 장착됨",
            "aa_footer_notice": "※ 건너뛴 노드는 기존 모델명이 그대로 유지됩니다.",
            "aa_btn_cancel": "닫기",
            "aa_btn_apply": "⚡ 선택한 모델 장착 / 확인",
            "aa_skip_current": "(건너뛰기 / 현재 유지)",
            "aa_smart_match": "스마트 추천:",
            "aa_folder_tree_open": "📂 폴더 트리 열기",
            "aa_folder_tree_close": "📂 폴더 트리 닫기",
            "aa_manual_select": "직접 선택",
            "aa_toast_applied": "✅ {count}개 모델이 성공적으로 장착되었습니다!",
            "aa_toast_none": "변경된 항목이 없습니다.",

            // --- Gemini Studio ---
            "gem_apikey_section": "🔑 API Key & 우선순위 모델 선택",
            "gem_apikey_placeholder": "Google Gemini API Key 입력...",
            "gem_apikey_save": "키 저장",
            "gem_apikey_saved": "키가 저장되었습니다!",
            "gem_gen_btn": "✨ AI 프롬프트 생성 (Shift+Enter)",
            "gem_gen_running": "프롬프트 생성 중...",
            "gem_copy_prompt": "📋 프롬프트 복사",
            "gem_copy_notes": "📝 해설 복사",
            "gem_tab_chat": "✨ 무검열 제미나이 (채팅)",
            "gem_toggle_nsfw_title": "성인용 콘텐츠 허용 (NSFW)",
            "gem_toggle_nsfw_desc": "관능적/친밀한 장면 무검열 묘사",
            "gem_toggle_trans_title": "한국어 번역 및 해설",
            "gem_toggle_trans_desc": "영문 프롬프트와 연출 해설 분할",
            "gem_prompt_input_placeholder": "생성하고자 하는 장면, 인물, 구도, 조명 등을 자세히 적어보세요...",
            "auto_assign": "자동 모델 & LoRA 스마트 매칭 알림",
            "auto_assign_desc": "워크플로우를 불러올 때 없는 모델이나 LoRA가 있으면 로컬 모델과 자동으로 매칭하여 안내창을 띄웁니다.",
            "sidebar_organizer": "사이드바 워크플로우 폴더 정리 및 이동",
            "sidebar_organizer_desc": "왼쪽 워크플로우 사이드바에서 워크플로우를 다른 폴더로 드래그하여 이동하거나 새 폴더를 생성할 수 있습니다.",
            "load_image_fix": "클립보드 & 로드 이미지 인풋 에러 자동 해결기",
            "load_image_fix_desc": "로드 이미지 노드에 Ctrl+V로 클립보드 이미지를 붙여넣거나 하위 경로를 불러올 때 발생하는 빨간 테두리 및 인풋 에러를 무결점으로 자동 해결합니다.",

            // --- Bada Preset Hub (Canvas Node) ---
            "hub_node_title": "⚓ Bada Preset Hub",
            "hub_select_nodes": "💡 캔버스에서 노드를 선택하세요 (Ctrl+클릭 / 드래그)",
            "hub_detected_nodes": "🎯 캔버스 선택 감지: {count}개 노드 (저장 가능)",
            "hub_settings_btn": "⚙️ 설정",
            "hub_presets_header": "📜 Bada 프리셋 ({count}개)",
            "hub_click_apply": "⚡ 클릭하여 즉시 적용",
            "hub_empty_hint": "💡 노드 선택 후 상단 버튼을 눌러 저장해 보세요",
            "hub_switch_on": "ON",
            "hub_switch_off": "OFF",

            // --- Smart Presets Context Menu & Roof Badges ---
            "ctx_global_presets": "⚓ 글로벌 프리셋 ({count})",
            "ctx_save_current": "💾 현재 세팅 글로벌 프리셋으로 저장...",
            "ctx_auto_assign_all": "⚓ [바다] 노드 스마트 케어",
            "ctx_auto_assign_node": "⚡ [바다] 이 노드 모델 자동 장착",
            "badge_global_title": "🌐 글로벌 프리셋 ({count}개)",
            "badge_global_desc": "<b>{name}</b> 노드에 저장된 전역 프리셋입니다.",
            "badge_global_action": "👉 클릭하여 글로벌 프리셋 관리자 열기",
            "badge_hub_title": "⚓ Bada 프리셋 허브 연동 ({count}개)",
            "badge_hub_desc": "<b>{name}</b> 노드가 포함된 {count}개의 Bada 프리셋이 허브에 등록되어 있습니다.",
            "badge_hub_action": "👉 클릭하여 Bada 프리셋 허브 관리자 열기",

            // --- Global Presets Modal ---
            "modal_global_title": "🌐 {name} 프리셋 관리자",
            "modal_global_subtitle": "노드 타입: {type} · ComfyUI 전역 저장 (동일 노드면 다른 워크플로우에서도 즉시 적용)",
            "modal_global_input_placeholder": "새 글로벌 프리셋 이름 입력 (예: Fast Turbo 8step)...",
            "modal_global_save_btn": "💾 현재 세팅 저장",
            "modal_global_empty": "저장된 프리셋이 없습니다.<br>위 입력창에 이름을 적고 <b>[현재 세팅 저장]</b>을 눌러보세요!",
            "modal_global_hint": "💡 태그(Pill)나 스위치를 클릭하여 원하는 옵션만 <b>켜고 끌 수 있으며(ON/OFF)</b>, <b>[상세 보기]</b>에서 값을 수정한 뒤 프리셋으로 저장 및 즉시 적용할 수 있습니다.",
            "modal_apply_btn": "▶ 즉시 적용",
            "modal_details_btn": "상세 보기",
            "modal_collapse_btn": "접기",
            "modal_export_btn": "📤 백업 (Export)",
            "modal_import_btn": "📥 불러오기 (Import)",
            "modal_guide_btn": "💡 백업 및 타 워크플로우 적용 가이드",
            "modal_close_btn": "닫기",

            // --- Bada Preset Hub Modal ---
            "modal_hub_title": "Bada 프리셋 허브 관리자",
            "modal_hub_subtitle": "Bada 프리셋은 <strong>현재 워크플로우에만 저장</strong>되며 워크플로우 저장(Ctrl+S) 및 이미지 생성 시 메타데이터에 자동 동봉됩니다",
            "modal_hub_input_placeholder": "새 유니버셜 프리셋 이름 입력 (예: FLUX 디테일러 세팅)...",
            "modal_hub_save_btn": "💾 현재 선택 노드로 저장",
            "modal_hub_empty": "저장된 유니버셜 프리셋이 없습니다.<br>캔버스에서 노드를 선택하고 <b>[현재 선택 노드로 저장]</b>을 눌러보세요!",
            "modal_hub_selected_count": "🎯 선택된 캔버스 노드 ({count}개)",
            "modal_hub_no_selection": "⚠️ 캔버스에서 선택된 노드가 없습니다. 먼저 노드들을 선택해 주세요!",
            "modal_hub_empty_badge": "⚠️ 선택된 노드 없음 (0개)",
            "modal_hub_empty_desc": "캔버스에서 묶고 싶은 노드들을 마우스로 선택(<b>Ctrl + 클릭</b> 또는 <b>Shift + 드래그</b>)한 후 저장해 주세요.",
            "modal_hub_target_badge": "🎯 저장 대상 노드: <strong>{count}개 선택됨</strong>",
            "modal_hub_target_hint": "※ 아래 노드들의 전체 세팅값이 하나의 유니버셜 프리셋 세트로 스냅샷 저장됩니다",
            "modal_hub_bypass_state": "🟣 바이패스 (Bypass) 상태",
            "modal_hub_mute_state": "🔴 뮤트 (Mute) 상태",
            "modal_hub_lora_none": "LoRA: 활성 항목 없음",
            "modal_hub_text_prefix": "텍스트",
            "modal_hub_default_params": "기본 파라미터 연동",
            "modal_hub_bypass_config": "바이패스 설정",
            "toast_hub_export_success": "📤 유니버셜 프리셋 JSON 백업 파일이 다운로드되었습니다.",
            "toast_hub_import_success": "📥 유니버셜 프리셋을 성공적으로 불러왔습니다!",
            "toast_hub_import_error": "⚠️ JSON 파일을 읽는 중 오류가 발생했습니다: ",
            "toast_global_export_success": "📤 글로벌 프리셋 JSON 백업 파일이 다운로드되었습니다.",
            "toast_global_import_success": "📥 글로벌 프리셋을 성공적으로 불러왔습니다!",

            // --- Workflows+ Sidebar ---
            "wf_tab_native": "Workflows",
            "wf_tab_plus": "⚓ 워크플로우+",
            "wf_search_placeholder": "워크플로우 검색...",
            "wf_btn_focus": "현재 작업 중인 워크플로우 위치로 이동",
            "wf_btn_font_size": "글자 크기 조절 (좌클릭: 순환 변경 / 우클릭: 메뉴)",
            "wf_btn_new_folder": "새 폴더 생성",
            "wf_btn_toggle_all": "모두 펼치기 / 접기",
            "wf_btn_refresh": "새로고침",
            "wf_root_dropzone": "🏠 최상위 폴더 (Root) 로 드롭하여 이동",
            "wf_empty_search": "검색 결과가 없습니다.",
            "wf_empty_list": "워크플로우가 없습니다.<br>상단 ➕ 로 새 폴더를 만드세요.",
            "wf_active_tag": "● 작업중",
            "wf_bookmarks_header": "Bookmarks",
            "wf_browse_header": "Browse",
            "wf_ctx_load": "불러오기 (Load)",
            "wf_ctx_fav_add": "즐겨찾기 추가",
            "wf_ctx_fav_remove": "즐겨찾기에서 제거",
            "wf_ctx_move": "폴더로 이동... (Move to)",
            "wf_ctx_new_subfolder": "하위 새 폴더 (New Subfolder)",
            "wf_ctx_rename": "이름 변경 (Rename)",
            "wf_ctx_delete": "삭제 (Delete)",
            "wf_ctx_edit_info": "정보 및 썸네일 설정...",
            "wf_info_modal_title": "⚓ 워크플로우 정보 및 썸네일",
            "wf_notes_label": "주석 및 설명 메모",
            "wf_notes_placeholder": "이 워크플로우의 특징, 권장 모델, 세팅 팁 등을 자유롭게 적어보세요...",
            "wf_thumb_label": "대표 썸네일 이미지",
            "wf_thumb_canvas_btn": "⚡ 캔버스 최근 생성물로 지정",
            "wf_thumb_paste_btn": "📋 클립보드 붙여넣기 (Ctrl+V)",
            "wf_thumb_upload_btn": "📁 이미지 업로드...",
            "wf_thumb_remove_btn": "🗑️ 썸네일 제거",
            "wf_thumb_drop_hint": "이미지를 여기에 드롭하거나 Ctrl+V 붙여넣기",
            "wf_thumb_pasted_toast": "클립보드 이미지가 등록되었습니다.",
            "wf_save_btn": "정보 저장",
            "wf_info_saved_toast": "워크플로우 정보와 썸네일이 저장되었습니다.",
            "wf_no_info_hint": "등록된 주석이나 썸네일이 없습니다.<br>(우클릭하여 정보 및 썸네일 등록)",
            "wf_card_path_label": "경로",
            "wf_card_notes_label": "주석/메모",
            "wf_modal_move_title": "📁 워크플로우 이동",
            "wf_modal_move_dest": "대상 폴더 선택",
            "wf_modal_move_or_sub": "또는 새 하위 폴더 생성",
            "wf_modal_move_btn": "이동하기",
            "wf_modal_mkdir_title": "➕ 새 폴더 생성",
            "wf_modal_mkdir_parent": "상위 폴더 (Parent)",
            "wf_modal_mkdir_name": "새 폴더 이름",
            "wf_modal_mkdir_btn": "생성하기",
            "wf_modal_rename_title": "✏️ {type} 이름 변경",
            "wf_modal_rename_btn": "변경하기",
            "wf_modal_delete_title": "🗑️ {type} 삭제",
            "wf_modal_delete_confirm": "정말로 <strong>'{name}'</strong> {target} 삭제하시겠습니까?",
            "wf_modal_delete_btn": "삭제",
            "wf_cancel_btn": "취소",

            // --- Save As 폴더 지정 저장 ---
            "wf_saveas_title": "💾 다른 이름으로 저장 (폴더 지정)",
            "wf_saveas_folder": "📁 저장할 폴더",
            "wf_saveas_root": "최상위 (Root)",
            "wf_saveas_name": "📄 파일 이름",
            "wf_saveas_name_required": "파일 이름을 입력해 주세요.",
            "wf_saveas_path": "저장 위치",
            "wf_saveas_exists": "(같은 이름의 파일이 이미 있습니다 - 덮어쓰기 확인창이 표시됩니다)",
            "wf_saveas_confirm": "저장",
            "wf_saveas_new_folder": "➕ 새 폴더",
            "wf_saveas_new_folder_ph": "새 폴더 이름",
            "wf_saveas_new_folder_btn": "생성",
            "wf_saveas_new_folder_done": "'{folder}' 폴더를 생성했습니다.",
            "wf_saveas_selected": "선택한 폴더",
            "wf_saveas_tree_hint": "클릭 = 선택 · ▶/▼ 또는 더블클릭 = 펼치기 · 방향키로 이동",


            // --- Regional Prompt ---
            "rp_art_style": "화풍:",
            "rp_hyper_real": "극실사",
            "rp_semi_real": "반실사",
            "rp_anime": "2D",
            "rp_character": "캐릭터",
            "rp_3d": "3D",
            "rp_none": "없음",
            "rp_white_bg": "백색 배경",
            "rp_grid_lines": "격자 실선",
            "rp_silhouette": "실루엣",
            "rp_global_char": "인물 공통 외모",
            "rp_char_preset_btn": "외모 프리셋 설정",
            "rp_select_area_hint": "📍 편집할 영역을 선택하세요",
            "rp_apply_btn": "적용 (Ctrl+Enter)",
            "rp_copy_btn": "복사 (Copy)",
            "rp_reset_btn": "초기화",
            "rp_final_preview": "최종 프롬프트 미리보기",

            // --- Bada Google Translator ---
            "trans_node_title": "⚓ Bada Google Translator",
            "trans_label_text": "번역할 원문 텍스트",
            "trans_label_from": "출발 언어 (from_lang)",
            "trans_label_to": "도착 언어 (to_lang)",
            "trans_label_quotes": "따옴표 원문 보존 (preserve_quotes)",
            "trans_tip_quotes": "True 시 큰따옴표(\" \") 안의 내용은 번역하지 않고 원문 그대로 유지합니다."
        }
    },

    /**
     * Get Bada Custom Node Language Setting
     * Strictly independent from ComfyUI native locale (Comfy.Locale has 0 effect)
     */
    getBadaLanguage(appInstance) {
        try {
            // 1) Direct BADA localStorage setting
            const direct = localStorage.getItem("BadaUtils_Language") || localStorage.getItem("BadaUtils.Language");
            if (direct === "ko" || direct === "en") return direct;

            // 2) ComfyUI App Settings API lookup for BadaUtils.Language
            const theApp = appInstance || comfyApp || (typeof window !== "undefined" ? window.app : null);
            const settingVal = theApp?.ui?.settings?.getSettingValue?.("BadaUtils.Language") ??
                               theApp?.ui?.settings?.settings?.["BadaUtils.Language"]?.value ??
                               theApp?.ui?.settings?.settingsValues?.["BadaUtils.Language"];
            if (settingVal) {
                const s = (typeof settingVal === "object" && settingVal.value) ? settingVal.value : String(settingVal);
                if (s === "ko" || s === "en") {
                    try {
                        localStorage.setItem("BadaUtils_Language", s);
                        localStorage.setItem("BadaUtils.Language", s);
                    } catch (e) {}
                    return s;
                }
            }

            // 3) ComfyUI settings localStorage entry
            const comfySetting = localStorage.getItem("Comfy.Settings.BadaUtils.Language");
            if (comfySetting) {
                const s = String(comfySetting).replace(/"/g, "").trim().toLowerCase();
                if (s === "ko" || s === "en") return s;
            }
        } catch (e) {}

        // Default to "en" (English First for ComfyUI Manager / Registry Compliance)
        return "en";
    },

    init(appInstance) {
        const newLang = this.getBadaLanguage(appInstance);
        if (newLang && newLang !== this._lang) {
            this._lang = newLang;
            this.notifyListeners();
        } else if (!this._lang) {
            this._lang = newLang;
        }
    },

    _isSettingLang: false,

    setLanguage(lang, updateComfySetting = false) {
        if (lang !== "ko" && lang !== "en") return;
        if (this._isSettingLang) return;
        this._isSettingLang = true;
        try {
            this._lang = lang;
            try {
                localStorage.setItem("BadaUtils_Language", lang);
                localStorage.setItem("BadaUtils.Language", lang);
                localStorage.setItem("Comfy.Settings.BadaUtils.Language", JSON.stringify(lang));
                if (updateComfySetting) {
                    const theApp = comfyApp || (typeof window !== "undefined" ? window.app : null);
                    if (theApp?.ui?.settings?.getSettingValue?.("BadaUtils.Language") !== lang) {
                        theApp?.ui?.settings?.setSettingValue?.("BadaUtils.Language", lang);
                    }
                }
            } catch (e) {}
            this.notifyListeners();
        } finally {
            this._isSettingLang = false;
        }
    },

    subscribe(listener) {
        if (typeof listener === "function") {
            this.listeners.add(listener);
        }
    },

    unsubscribe(listener) {
        this.listeners.delete(listener);
    },

    notifyListeners() {
        for (const listener of this.listeners) {
            try {
                listener(this.lang);
            } catch (e) {
                console.warn("[BadaI18n] listener notification error:", e);
            }
        }
    },

    /**
     * Tier 1 Translation (For Settings dialog based on current Bada/ComfyUI language)
     */
    tSettings(key, app, params = {}) {
        const lang = this.lang || this.getBadaLanguage(app);
        const dict = this.dict[lang] || this.dict.en;
        let str = dict[key] || this.dict.en[key] || key;
        for (const [k, v] of Object.entries(params)) {
            str = str.replace(new RegExp(`\\{${k}\\}`, "g"), v);
        }
        return str;
    },

    /**
     * Tier 2 Translation (For Bada Nodes, Badges, Modals, Menus controlled by Bada Language setting)
     */
    t(key, params = {}) {
        const currentDict = this.dict[this.lang] || this.dict.en;
        let str = currentDict[key] || this.dict.en[key] || key;
        for (const [k, v] of Object.entries(params)) {
            str = str.replace(new RegExp(`\\{${k}\\}`, "g"), v);
        }
        return str;
    }
};

// Immediate background auto-sync from ComfyUI /settings backend
(async function autoSyncServerSettings() {
    try {
        const res = await fetch("/settings");
        if (res.ok) {
            const settings = await res.json();
            const lang = settings?.["BadaUtils.Language"];
            if (lang === "ko" || lang === "en") {
                try {
                    localStorage.setItem("BadaUtils_Language", lang);
                    localStorage.setItem("BadaUtils.Language", lang);
                } catch (e) {}
                if (BadaI18n._lang !== lang) {
                    BadaI18n.setLanguage(lang, false);
                }
            }
        }
    } catch (e) {}
})();

window.BadaI18n = BadaI18n;


